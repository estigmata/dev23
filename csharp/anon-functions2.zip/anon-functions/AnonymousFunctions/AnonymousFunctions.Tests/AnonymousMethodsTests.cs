﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using AnonymousFunctions.AnonymousMethod;

namespace AnonymousFunctions.Tests
{
    [TestClass]
    public class AnonymousMethodsTests
    {
        [TestMethod]
        public void TestExample1()
        {
            Assert.IsTrue(Example1.IsPositiveNumber(5));
            Assert.IsFalse(Example1.IsPositiveNumber(-5));
        }

        [TestMethod]
        public void TestExample2()
        {
            Assert.IsTrue(Example2.IsPositiveNumber(10));
            Assert.IsFalse(Example2.IsPositiveNumber(-10));
        }

        [TestMethod]
        public void TestExample3()
        {
            Assert.IsTrue(Example3.IsPositiveNumber(15));
            Assert.IsFalse(Example3.IsPositiveNumber(-15));
        }

        [TestMethod]
        public void TestExample4Wrong()
        {
            Assert.AreEqual(51, Example4Wrong.IncreaseNumber(1));
        }
    }
}
