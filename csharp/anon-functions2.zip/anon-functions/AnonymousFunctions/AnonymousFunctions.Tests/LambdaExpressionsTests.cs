﻿using System;
using AnonymousFunctions.LambdaExpressions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace AnonymousFunctions.Tests
{
    [TestClass]
    public class LambdaExpressionsTests
    {
        [TestMethod]
        public void TestExample11()
        {
            Assert.AreEqual(100, Example11.Multiply1());
        }
    }
}
