﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousFunctions.LambdaExpressions
{
    delegate bool D();
    delegate bool D2(int i);

    class Test
    {
        public D del;
        public D2 del2;

        public void TestMethod(int input)
        {
            int j = 0;

            del = () => { j = 10; return j > input; };

            del2 = (x) => { return x == j; };

            // Qué imprime aqui?
            Console.WriteLine("j = {0}", j);
            // Cual es el resultado de boolResult?
            bool boolResult = del();

            // Qué imprime aqui?
            Console.WriteLine("j = {0}. b = {1}", j, boolResult);
        }
    }
}
