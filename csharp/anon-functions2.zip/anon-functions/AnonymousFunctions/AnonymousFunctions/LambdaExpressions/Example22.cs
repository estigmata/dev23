﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousFunctions.LambdaExpressions
{
    public class Example22
    {
        private delegate bool OtherDelegate(int x, string s);

        public static void OtherMethod1()
        {
            OtherDelegate otherDelegate = (int x, string s) => s.Length > x;

            var abc = otherDelegate(3, "hello world");
        }

        public static void OtherMethod2()
        {
            OtherDelegate otherDelegate = (x, s) => s.Length > x;

            var abc = otherDelegate(11, "hello world");
        }

        public static void OtherMethod3()
        {
            Action actionDelegate = () => SomeMethod();
            actionDelegate();
        }

        private static void SomeMethod()
        {
        }

        /// <summary>
        /// This is not using lambda expressions
        /// </summary>
        public static void OtherMethod4()
        {
            Action actionDelegate = SomeMethod;
            actionDelegate();
        }
    }
}
