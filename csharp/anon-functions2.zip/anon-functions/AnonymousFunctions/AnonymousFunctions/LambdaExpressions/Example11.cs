﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousFunctions.LambdaExpressions
{
    public class Example11
    {
        private delegate int MyDelegate(int i);

        public static int Multiply1()
        {
            MyDelegate myDelegate = x => x * x;
            var result = myDelegate(10);
            return result;
        }
    }
}
