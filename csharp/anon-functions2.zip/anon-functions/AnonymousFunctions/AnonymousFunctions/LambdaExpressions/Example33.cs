﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousFunctions.LambdaExpressions
{
    public class Example33
    {
        delegate void TestDelegate(string s);

        /// <summary>
        /// Statement lambdas
        /// A statement lambda resembles an expression lambda except that the statement is enclosed in braces:
        /// (input-parameters) => { statement; }
        /// </summary>
        public static void TestMethod()
        {
            TestDelegate del = n => {
                string s = n + " World";
                Console.WriteLine(s);
            };
        }
    }
}
