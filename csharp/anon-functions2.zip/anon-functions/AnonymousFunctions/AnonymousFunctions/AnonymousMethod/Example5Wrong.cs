﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousFunctions.AnonymousMethod
{
    public class Example5Wrong
    {
        public static int IncreaseNumber(int number)
        {
            Action actionDelegate = delegate ()
            {
                number++;
            };

            actionDelegate();
            return number;
        }

        public static void IncreaseNumberWrong(out int number)
        {
            number = 0;

            Action actionDelegate = delegate ()
            {
                //number++;
            };

            actionDelegate();
        }

        public static void DecreaseNumberWrong(ref int number)
        {
            Action actionDelegate = delegate ()
            {
                //number++;
            };

            actionDelegate();
        }
    }
}
