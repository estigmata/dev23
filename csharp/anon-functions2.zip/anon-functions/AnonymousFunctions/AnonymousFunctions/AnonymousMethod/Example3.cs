﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousFunctions.AnonymousMethod
{
    public class Example3
    {
        public static bool IsPositiveNumber(int number)
        {
            // The local variables and parameters whose scope contains an anonymous method 
            // declaration are called outer variables of the anonymous method.
            // number is an outer variable
            Func<bool> funcDelegate = delegate ()
            {
                return number > 0;
            };

            return funcDelegate();
        }
    }
}
