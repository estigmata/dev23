﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousFunctions.AnonymousMethod
{
    public class Example2
    {
        public static bool IsPositiveNumber(int number)
        {
            Func<int, bool> funcDelegate = delegate (int int32)
            {
                return int32 > 0;
            };

            return funcDelegate(number);
        }
    }
}
