﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousFunctions.AnonymousMethod
{
    public class Example1
    {
        private delegate bool IsPositiveDelegate(int int32);

        public static bool IsPositiveNumber(int number)
        {
            IsPositiveDelegate myDelegate = delegate (int int32)
            {
                return int32 > 0;
            };

            return myDelegate(number);
        }
    }
}
