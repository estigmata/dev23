﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousFunctions.AnonymousMethod
{
    public class Example4Wrong
    {
        // It is an error to have a jump statement, such as goto, 
        // break, or continue, inside the anonymous method block if the target 
        // is outside the block.
        public static int IncreaseNumber(int number)
        {
            for (int i = 0; i < 100; i++)
            {
                Action actionDelegate = delegate ()
                {
                    number++;

                    if (number == 50)
                    {
                        //break;
                        //continue;
                    }
                };

                actionDelegate();
            }

            return number;
        }
    }
}
