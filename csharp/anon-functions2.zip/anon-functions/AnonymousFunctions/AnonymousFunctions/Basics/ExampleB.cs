﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousFunctions.Basics
{
    class ExampleB
    {
        public delegate void MyDelegate(string text);

        public void Main(string[] args)
        {
            // C# 2.0: A delegate can be initialized with
            // inline code, called an "anonymous method." This
            // method takes a string as an input parameter.
            MyDelegate delegateB = delegate(string text) { Console.WriteLine(text); };

            // Invoking the delegate.
            delegateB("Invoking delegate B. C# 2.0 style.");

            Console.ReadKey();
        }
    }
}
