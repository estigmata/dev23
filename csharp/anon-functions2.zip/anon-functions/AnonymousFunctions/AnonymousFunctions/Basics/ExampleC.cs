﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousFunctions.Basics
{
    class ExampleC
    {
        public delegate void MyDelegate(string text);

        public void Main(string[] args)
        {
            // C# 3.0. A delegate can be initialized with
            // a lambda expression. The lambda also takes a string
            // as an input parameter (x). The type of x is inferred by the compiler.
            MyDelegate delegateC = (x) => { Console.WriteLine(x); };

            // Invoking the delegate.
            delegateC("Invoking delegate C. C# 3.0 style.");

            Console.ReadKey();
        }
    }
}
