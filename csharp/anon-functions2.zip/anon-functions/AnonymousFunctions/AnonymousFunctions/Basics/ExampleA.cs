﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousFunctions.Basics
{
    class ExampleA
    {
        public delegate void MyDelegate(string text);

        public void MyMethod(string text)
        {
            Console.WriteLine(text);
        }

        public void Main(string[] args)
        {
            // C# 1.0: Original delegate syntax required 
            // initialization with a named method.
            MyDelegate delegateA = new MyDelegate(MyMethod);

            // Invoking the delegate.
            delegateA("Invoking delegate A. C# 1.0 style.");

            Console.ReadKey();
        }
    }
}
