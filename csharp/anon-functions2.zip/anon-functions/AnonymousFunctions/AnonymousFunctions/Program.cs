﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AnonymousFunctions.LambdaExpressions;

namespace AnonymousFunctions
{
    class Program
    {
        static void Main(string[] args)
        {
            // Analysing lambda expressions in 'Test' class

            Test test = new Test();
            test.TestMethod(5);

            bool result = test.del2(10);

            // Que imprime aqui?
            Console.WriteLine(result);

            Console.ReadKey();
        }
    }
}
