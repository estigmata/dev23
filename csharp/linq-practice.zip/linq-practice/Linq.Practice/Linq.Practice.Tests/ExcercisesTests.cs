﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Linq.Practice.Managers;
using System.Linq;

namespace Linq.Practice.Tests
{
    [TestClass]
    public class ExcercisesTests
    {
        [TestMethod]
        public void Sample1()
        {
            var pm = new ProductManager();
            var products = pm.GetProductList();

            Assert.AreEqual(77, products.Count);

            // Select all products with price less than 25.0000M.
            var query = products.Where(p => p.UnitPrice < 25.000M);
            var count = 0;

            foreach (var prod in query)
            {
                Console.WriteLine(++count + " - " + prod.UnitPrice);
            }

            Assert.AreEqual(48, query.Count());

            CustomerManager cm = new CustomerManager();
            var customers = cm.GetCustomerList();

            foreach (var item in customers)
            {
                Console.WriteLine(item.CustomerID);
            }
        }

        [TestMethod]
        public void Excercise1()
        {

        }
    }
}
