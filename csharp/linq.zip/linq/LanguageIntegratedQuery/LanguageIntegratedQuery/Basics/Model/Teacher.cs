﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LanguageIntegratedQuery.Basics.Model
{
    public class Teacher
    {
        public string Name { get; set; }

        public bool Enabled { get; set; }
    }
}
