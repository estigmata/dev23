﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionExamples
{
    class Program
    {
        public static void Main(string[] args)
        {
            //System.Reflection.Assembly
            //System.Reflection.Module
            //System.Reflection.ConstructorInfo
            //System.Reflection.MethodInfo
            //System.Reflection.FieldInfo
            //System.Reflection.EventInfo
            //System.Reflection.PropertyInfo
            //System.Reflection.ParameterInfo
            //System.Reflection.CustomAttributeData
        }
    }
}
