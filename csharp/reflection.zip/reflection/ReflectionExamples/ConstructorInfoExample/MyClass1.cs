﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorInfoExample
{
    public class MyClass1
    {
        public MyClass1(int i)
        {
        }
    }
}
