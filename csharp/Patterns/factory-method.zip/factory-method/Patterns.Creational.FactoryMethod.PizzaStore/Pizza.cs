﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patterns.Creational.FactoryMethod.PizzaStore
{
    abstract class Pizza
    {
        protected string name;

        internal virtual void Prepare()
        {
            Console.WriteLine($"Preparing {name}");
        }

        internal virtual void Bake()
        {
            Console.WriteLine("Bake for 15 minutes at 180");
        }

        internal virtual void Box()
        {
            Console.WriteLine("Boxing pizza");
        }

        internal virtual void Cut()
        {
            Console.WriteLine("Cutting pizza into diagonal slices");
        }
    }
}
