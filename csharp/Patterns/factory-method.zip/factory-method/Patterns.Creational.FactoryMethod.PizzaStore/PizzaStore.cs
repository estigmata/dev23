﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patterns.Creational.FactoryMethod.PizzaStore
{
    abstract class PizzaStore
    {
        public Pizza OrderPizza(string name)
        {
            Pizza pizza = CreatePizza(name);

            pizza.Prepare();
            pizza.Bake();
            pizza.Cut();
            pizza.Box();

            return pizza;
        }

        protected abstract Pizza CreatePizza(string name);
    }
}
