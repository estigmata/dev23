﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patterns.Creational.FactoryMethod.PizzaStore
{
    class ChicagoPizzaStore : PizzaStore
    {
        protected override Pizza CreatePizza(string name)
        {
            if (name == "cheese")
            {
                return new ChicagoStyleCheesePizza();
            }
            else if (name == "pepperoni")
            {
                return new ChicagoStylePepperoniPizza();
            }

            return null;
        }
    }
}
