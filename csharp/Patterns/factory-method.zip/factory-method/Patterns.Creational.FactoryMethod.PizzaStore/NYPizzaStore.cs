﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patterns.Creational.FactoryMethod.PizzaStore
{
    class NYPizzaStore : PizzaStore
    {
        protected override Pizza CreatePizza(string name)
        {
            if (name == "cheese")
            {
                return new NYStyleCheesePizza();
            }
            else if (name == "pepperoni")
            {
                return new NYStylePepperoniPizza();
            }

            return null;
        }
    }
}
