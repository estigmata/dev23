﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patterns.Creational.FactoryMethod.PizzaStore
{
    class Program
    {
        static void Main(string[] args)
        {
            PizzaStore pizzaStore1 = new NYPizzaStore();
            pizzaStore1.OrderPizza("cheese");

            Console.WriteLine();

            PizzaStore pizzaStore2 = new ChicagoPizzaStore();
            pizzaStore2.OrderPizza("cheese");
            pizzaStore2.OrderPizza("pepperoni");
        }
    }
}
