﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patterns.Creational.FactoryMethod
{
    class ConcreteCreator2 : Creator
    {
        public override Product FactoryMethod(string type)
        {
            if (type == "first")
            {
                return new ConcreteProductA();
            }
            else if (type == "second")
            {
                return new ConcreteProductB();
            }

            return null;
        }
    }
}
