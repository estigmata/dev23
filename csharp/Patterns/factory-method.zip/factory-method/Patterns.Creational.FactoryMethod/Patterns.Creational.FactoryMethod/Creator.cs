﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patterns.Creational.FactoryMethod
{
    abstract class Creator
    {
        public Product Operation(string type)
        {
            Product product = FactoryMethod(type);

            // Do something here with product object
            product.Process();

            return product;
        }

        public abstract Product FactoryMethod(string type);
    }
}
