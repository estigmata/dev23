﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patterns.Creational.FactoryMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            Creator creator1 = new ConcreteCreator1();
            Product product1 = creator1.Operation("first");

            Creator creator2 = new ConcreteCreator2();
            Product product2 = creator2.Operation("first");
        }
    }
}
