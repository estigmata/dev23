﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patterns.Creational.FactoryMethod
{
    class ConcreteCreator1 : Creator
    {
        public override Product FactoryMethod(string type)
        {
            if (type == "first")
            {
                return new ConcreteProduct1();
            }
            else if (type == "second")
            {
                return new ConcreteProduct2();
            }

            return null;
        }
    }
}
