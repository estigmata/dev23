﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solid.Principles.OCPViolation.Practice
{
    public enum ResourceType
    {
        TIME_SLOT,
        SPACE_SLOT
    }
}
