﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solid.Principles.LSP.Resources
{
    public interface IPersistResource
    {
        void Persist();
    }
}
