﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solid.Principles.LSP.Resources
{
    public class SpecialSettings : ILoadResource
    {
        public void Load()
        {
            // Load special settings
        }
    }
}
