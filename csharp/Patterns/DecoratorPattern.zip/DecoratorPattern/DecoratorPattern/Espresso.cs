﻿namespace DecoratorPattern
{
    class Espresso : Beverage
    {
        public Espresso()
        {
            description = "Espresso";
        }

        public override double Cost
        {
            get
            {
                return 15.49;
            }
        }
    }
}
