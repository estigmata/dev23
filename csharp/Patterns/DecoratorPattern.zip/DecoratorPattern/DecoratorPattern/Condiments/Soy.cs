﻿namespace DecoratorPattern.Condiments
{
    class Soy : CondimentDecorator
    {
        public Soy(Beverage beverage) : base(beverage)
        {
        }

        public override double Cost
        {
            get { return 0.45 + Beverage.Cost; }
        }

        public override string GetDescription()
        {
            return Beverage.GetDescription() + " + Soy";
        }
    }
}
