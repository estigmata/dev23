﻿namespace DecoratorPattern.Condiments
{
    abstract class CondimentDecorator : Beverage
    {
        public CondimentDecorator(Beverage beverage)
        {
            Beverage = beverage;
        }

        protected Beverage Beverage { get; set; }
    }
}
