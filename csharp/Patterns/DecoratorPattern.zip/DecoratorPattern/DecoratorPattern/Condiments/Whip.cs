﻿namespace DecoratorPattern.Condiments
{
    class Whip : CondimentDecorator
    {
        public Whip(Beverage beverage) : base(beverage)
        {
        }

        public override double Cost
        {
            get { return 0.20 + Beverage.Cost; }
        }

        public override string GetDescription()
        {
            return Beverage.GetDescription() + " + Whip";
        }
    }
}
