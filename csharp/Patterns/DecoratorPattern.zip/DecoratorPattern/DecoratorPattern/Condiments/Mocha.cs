﻿namespace DecoratorPattern.Condiments
{
    class Mocha : CondimentDecorator
    {
        public Mocha(Beverage beverage) : base(beverage)
        {
        }

        public override double Cost
        {
            get { return 0.10 + Beverage.Cost; }
        }

        public override string GetDescription()
        {
            return Beverage.GetDescription() + " + Mocha";
        }
    }
}
