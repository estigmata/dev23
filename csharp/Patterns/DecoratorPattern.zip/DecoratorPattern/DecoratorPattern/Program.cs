﻿using DecoratorPattern.Condiments;

namespace DecoratorPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            Beverage beverage = new Espresso();
            System.Console.WriteLine($"{beverage.GetDescription()}, {beverage.Cost}");

            beverage = new Mocha(beverage);
            beverage = new Mocha(beverage);
            beverage = new Whip(beverage);
            System.Console.WriteLine($"{beverage.GetDescription()}, {beverage.Cost}");

            System.Console.ReadKey();
        }
    }
}
