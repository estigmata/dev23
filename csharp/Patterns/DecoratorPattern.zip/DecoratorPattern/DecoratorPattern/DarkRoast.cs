﻿namespace DecoratorPattern
{
    class DarkRoast : Beverage
    {
        public DarkRoast()
        {
            description = "Dark Roast";
        }

        public override double Cost
        {
            get
            {
                return 10.99;
            }
        }
    }
}
